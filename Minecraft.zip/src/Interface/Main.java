package Interface;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;

import Bloc.Bloc;
import Bloc.Bloc_mangeable;
import Craft.Recette;
import Craft.TableCraft;
import Entite.Joueur;
import Entite.Monstres;
import Item.Armure;
import Item.Item;
import Item.Outils;

public class Main {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
        Joueur joueur = new Joueur("Steve");
        boolean jeuEnCours = true;
        
        //On donner au joueur quelques objets pour faciliter l'aventure.
        joueur.ajouterInventaire(new Outils("Epee en bois", 10)); 
        joueur.ajouterInventaire(new Armure("Bouclier en fer", 15)); 
        joueur.ajouterInventaire(new Item("Potion de soin")); 
        
        joueur.ajouterInventaire(new Item("Baton en bois"));
        joueur.ajouterInventaire(new Item("Fer"));
        joueur.ajouterInventaire(new Item("Cuir"));
        joueur.ajouterInventaire(new Item("Cuir"));
        joueur.ajouterInventaire(new Item("Eau"));
        joueur.ajouterInventaire(new Item("Potion"));
        joueur.ajouterInventaire(new Item("Bois"));
        joueur.ajouterInventaire(new Item("Bois"));
        joueur.ajouterInventaire(new Bloc_mangeable("Potion", 10));



        TableCraft table = TableCraft.getTable();

     Recette recette1 = new Recette(new Outils("Epee en fer", 20));
     recette1.ajouterIngredients(new Item("Baton en bois"));
     recette1.ajouterIngredients(new Item("Fer"));
     recette1.ajouterIngredients(new Item("Fer"));
     table.ajouterRecette(recette1);

     Recette recette2 = new Recette(new Armure("Armure en cuir", 10));
     recette2.ajouterIngredients(new Item("Cuir"));
     recette2.ajouterIngredients(new Item("Cuir"));
     table.ajouterRecette(recette2);

     Recette recette3 = new Recette(new Armure("Bouclier en bois", 5));
     recette3.ajouterIngredients(new Item("Bois"));
     recette3.ajouterIngredients(new Item("Bois"));
     table.ajouterRecette(recette3);

     Recette recette4 = new Recette(new Armure("Casque en fer", 8));
     recette4.ajouterIngredients(new Item("Fer"));
     recette4.ajouterIngredients(new Item("Fer"));
     recette4.ajouterIngredients(new Item("Fer"));
     table.ajouterRecette(recette4);

     Recette recette5 = new Recette(new Armure("Plastron en diamant", 30));
     recette5.ajouterIngredients(new Item("Diamant"));
     recette5.ajouterIngredients(new Item("Diamant"));
     recette5.ajouterIngredients(new Item("Diamant"));
     recette5.ajouterIngredients(new Item("Diamant"));
     table.ajouterRecette(recette5);

     Recette recette6 = new Recette(new Outils("Pioche en pierre", 15));
     recette6.ajouterIngredients(new Item("Baton en bois"));
     recette6.ajouterIngredients(new Item("Baton en bois"));
     recette6.ajouterIngredients(new Item("Pierre"));
     recette6.ajouterIngredients(new Item("Pierre"));
     recette6.ajouterIngredients(new Item("Pierre"));
     table.ajouterRecette(recette6);

     Recette recette7 = new Recette(new Outils("Épée en diamant", 40));
     recette7.ajouterIngredients(new Item("Baton en bois"));
     recette7.ajouterIngredients(new Item("Diamant"));
     recette7.ajouterIngredients(new Item("Diamant"));
     table.ajouterRecette(recette7);

     Recette recette8 = new Recette(new Outils("Pelle en fer", 10));
     recette8.ajouterIngredients(new Item("Baton en bois"));
     recette8.ajouterIngredients(new Item("Fer"));
     table.ajouterRecette(recette8);

     Recette recette9 = new Recette(new Outils("Arc", 15));
     recette9.ajouterIngredients(new Item("Baton en bois"));
     recette9.ajouterIngredients(new Item("Baton en bois"));
     recette9.ajouterIngredients(new Item("Toile"));
     table.ajouterRecette(recette9);

     Recette recette11 = new Recette(new Bloc_mangeable("Pain", 5));
     recette11.ajouterIngredients(new Item("Ble"));
     recette11.ajouterIngredients(new Item("Ble"));
     recette11.ajouterIngredients(new Item("Ble"));
     table.ajouterRecette(recette11);

     Recette recette12 = new Recette(new Bloc_mangeable("Potion de soin", 20));
     recette12.ajouterIngredients(new Item("Eau"));
     recette12.ajouterIngredients(new Item("Potion"));
     table.ajouterRecette(recette12);

     Recette recette13 = new Recette(new Armure("Bouclier en fer", 20));
     recette13.ajouterIngredients(new Item("Fer"));
     recette13.ajouterIngredients(new Item("Fer"));
     recette13.ajouterIngredients(new Item("Bois"));
     table.ajouterRecette(recette13);

     Recette recette14 = new Recette(new Outils("Hache en fer", 18));
     recette14.ajouterIngredients(new Item("Baton en bois"));
     recette14.ajouterIngredients(new Item("Fer"));
     recette14.ajouterIngredients(new Item("Fer"));
     table.ajouterRecette(recette14);

     Recette recette15 = new Recette(new Armure("Bottes en cuir", 5));
     recette15.ajouterIngredients(new Item("Cuir"));
     recette15.ajouterIngredients(new Item("Cuir"));
     table.ajouterRecette(recette15);

        while (jeuEnCours) {
            System.out.println("\nMenu principal :");
            System.out.println("1. Jouer en solo");
            System.out.println("2. Jouer en multijoueur");
            System.out.println("3. Quitter");

            System.out.print("Choisissez une option : ");
            int choixPrincipal = scanner.nextInt();
            scanner.nextLine(); // Lire le choix du joueur

            switch (choixPrincipal) {
                case 1: // Mode solo
                    boolean soloEnCours = true;
                    while (soloEnCours) {
                        System.out.println("\nMenu Solo :");
                        System.out.println("1. Se deplacer");
                        System.out.println("2. Crafter");
                        System.out.println("3. Gestion de l'inventaire");
                        System.out.println("4. Gestion de l'equipement (armures/outils)");
                        System.out.println("5. Retour au menu principal");

                        System.out.print("Choisissez une action : ");
                        int choixSolo = scanner.nextInt();
                        scanner.nextLine(); 

                        switch (choixSolo) {
                            case 1: // Se déplacer
                                joueur.se_deplacer();
                                break;

                            case 2: // Crafter
                                joueur.crafter();
                                break;

                            case 3: // Gestion de l'inventaire
                                System.out.println("\nGestion de l'inventaire :");
                                System.out.println("1. Afficher l'inventaire");
                                System.out.println("2. Supprimer un objet");
                                System.out.println("3. Manger");
                                System.out.print("Votre choix : ");
                                int choixInventaire = scanner.nextInt();
                                scanner.nextLine(); // Consommer la nouvelle ligne

                                if (choixInventaire == 1) { // Afficher l'inventaire
                                    joueur.afficherInventaire();
                                } 
                                else if (choixInventaire == 2) { // Supprimer un objet
                                    joueur.afficherInventaire();
                                    System.out.println("Entrez le numero de l'objet a supprimer (ou -1 pour annuler) :");
                                    int indexSuppression = scanner.nextInt();
                                    scanner.nextLine(); // Consommer la nouvelle ligne

                                    if (indexSuppression == -1) {
                                        System.out.println("Suppression annulee.");
                                    } 
                                    else if (indexSuppression >= 1 && indexSuppression <= joueur.getInventaire().size()) {
                                        Item objetSupprime = joueur.getInventaire().get(indexSuppression - 1);
                                        joueur.supprimerInventaire(objetSupprime);
                                    } 
                                    else {
                                        System.out.println("Index invalide. Reessayez.");
                                    }
                                }
                                else if (choixInventaire == 3) { // Manger un bloc mangeable
                                    joueur.afficherInventaire();
                                    System.out.println("Entrez le numero du bloc mangeable a manger (ou -1 pour annuler) :");
                                    int indexManger = scanner.nextInt();
                                    scanner.nextLine(); // Consommer la nouvelle ligne

                                    if (indexManger == -1) {
                                        System.out.println("Action annulee.");
                                    } 
                                    else if (indexManger >= 1 && indexManger <= joueur.getInventaire().size()) {
                                        Item objet = joueur.getInventaire().get(indexManger - 1);

                                        if (objet instanceof Bloc_mangeable) { // Vérifie si l'objet est mangeable
                                            Bloc_mangeable bloc = (Bloc_mangeable) objet;
                                            
                                            // Stocke les PV actuels avant consommation
                                            int pvAvant = joueur.getPointsDeVie();

                                            // Restaure les points de vie
                                            joueur.setPointsDeVie(joueur.getPointsDeVie() + bloc.getPointsDeVie());

                                            // Affiche les informations sur les PV
                                            System.out.println("Vous mangez : " + bloc.getNom() + " et regagnez " + bloc.getPointsDeVie() + " PV.");
                                            System.out.println("Vos PV actuels : " + joueur.getPointsDeVie() + " (avant : " + pvAvant + ")");

                                            // Supprime le bloc de l'inventaire
                                            joueur.supprimerInventaire(bloc);
                                        } 
                                        else {
                                            System.out.println("Cet objet n'est pas mangeable.");
                                        }
                                    } 
                                    else {
                                        System.out.println("Index invalide. Reessayez.");
                                    }
                                }

                                else {
                                    System.out.println("Choix invalide.");
                                }
                                break;
                                
                            case 4: // Gestion de l'équipement
                                System.out.println("\nGestion de l'equipement :");
                                System.out.println("1. Gestion des armures (equiper/enlever)");
                                System.out.println("2. Gestion des outils (equiper/enlever)");
                                System.out.print("Votre choix : ");
                                int choixEquipement = scanner.nextInt();
                                scanner.nextLine(); // Consommer la nouvelle ligne

                                if (choixEquipement == 1) { // Gestion des armures
                                    System.out.println("\nGestion des armures :");
                                    System.out.println("1. Equiper une armure");
                                    System.out.println("2. Enlever l'armure");
                                    System.out.print("Votre choix : ");
                                    int choixArmure = scanner.nextInt();
                                    scanner.nextLine(); // Consommer la nouvelle ligne

                                    if (choixArmure == 1) { // Équiper une armure
                                        joueur.afficherInventaire();
                                        System.out.println("Entrez le numero de l'armure a equiper (ou -1 pour annuler) :");
                                        int indexArmure = scanner.nextInt();
                                        scanner.nextLine(); // Consommer la nouvelle ligne

                                        if (indexArmure == -1) {
                                            System.out.println("Equipement annule.");
                                        } 
                                        else if (indexArmure >= 1 && indexArmure <= joueur.getInventaire().size()) {
                                            Item armure = joueur.getInventaire().get(indexArmure - 1);

                                            if (armure instanceof Armure) {
                                                joueur.equiperArmure((Armure) armure);
                                            } 
                                            else {
                                                System.out.println("Cet objet n'est pas une armure.");
                                            }
                                        } 
                                        else {
                                            System.out.println("Index invalide. Reessayez.");
                                        }
                                    } 
                                    else if (choixArmure == 2) { // Enlever l'armure
                                        joueur.enleverArmure(joueur.getArmureEquipee()); // Enlève directement l'armure équipée
                                    } 
                                    else {
                                        System.out.println("Choix invalide.");
                                    }

                                } 
                                else if (choixEquipement == 2) { // Gestion des outils
                                    System.out.println("\nGestion des outils :");
                                    System.out.println("1. Equiper un outil");
                                    System.out.println("2. Enlever l'outil");
                                    System.out.print("Votre choix : ");
                                    int choixOutil = scanner.nextInt();
                                    scanner.nextLine(); // Consommer la nouvelle ligne

                                    if (choixOutil == 1) { // Équiper un outil
                                        joueur.afficherInventaire();
                                        System.out.println("Entrez le numero de l'outil a equiper (ou -1 pour annuler) :");
                                        int indexOutil = scanner.nextInt();
                                        scanner.nextLine(); // Consommer la nouvelle ligne

                                        if (indexOutil == -1) {
                                            System.out.println("Equipement annule.");
                                        } 
                                        else if (indexOutil >= 1 && indexOutil <= joueur.getInventaire().size()) {
                                            Item outil = joueur.getInventaire().get(indexOutil - 1);

                                            if (outil instanceof Outils) {
                                                joueur.equiperArme((Outils) outil);
                                            } 
                                            else {
                                                System.out.println("Cet objet n'est pas un outil.");
                                            }
                                        } 
                                        else {
                                            System.out.println("Index invalide. Reessayez.");
                                        }
                                    }
                                    else if (choixOutil == 2) { // Enlever l'outils
                                        joueur.enleverArmure(joueur.getArmureEquipee()); // Enlève directement l'outils équipée
                                    } 
                                    else {
                                        System.out.println("Choix invalide.");
                                    }
                                } 
                                else {
                                    System.out.println("Choix invalide.");
                                }
                                break;

                            case 5: // Retour au menu principal
                                soloEnCours = false;
                                break;

                            default:
                                System.out.println("Action invalide !");
                        }
                    }
                    break;

               
                case 2: // Mode multijoueur
                    System.out.println("Connexion au serveur...");
                    try (Socket socket = new Socket(InetAddress.getLocalHost(), 7003)) {
                        System.out.println("Connecté au serveur.");

                        ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
                        ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());

                        Joueur joueurLocal = new Joueur("Steve");
                        joueurLocal.equiperArme(new Outils("Épée en bois", 10));

                        // Envoyer le joueur au serveur
                        oos.writeObject(joueurLocal);

                        boolean jeuEnCours1 = true;
                        while (jeuEnCours1) {
                            // Recevoir l'état des joueurs depuis le serveur
                            Joueur j1 = (Joueur) ois.readObject();
                            Joueur j2 = (Joueur) ois.readObject();

                            // Afficher les points de vie
                            System.out.println("Joueur 1 - PV: " + j1.getPointsDeVie() + ", Joueur 2 - PV: " + j2.getPointsDeVie());

                            // Vérifier si le combat est terminé
                            if (!j1.estVivant() || !j2.estVivant()) {
                                if (j1.estVivant()) {
                                    System.out.println("Joueur 1 a gagne !");
                                } else {
                                    System.out.println("Joueur 2 a gagne !");
                                }
                                oos.writeObject("FIN"); // Envoyer le signal de fin au serveur
                                break;
                            }

                          
                                System.out.println("Joueur 1 attaque !");
                                j1.attaquer(j2);
                                System.out.println("Joueur 2 - PV: " + j2.getPointsDeVie());
                                // Envoyer l'état mis à jour au serveur (y compris les modifications sur j1 et j2)
                                oos.writeObject(j1); // Envoyer l'état mis à jour de j1
                                oos.writeObject(j2); // Envoyer l'état mis à jour de j2

                            
                            }

                        
                        Object retourServeur = ois.readObject();
                        if (retourServeur instanceof String) {
                            String message = (String) retourServeur;
                            if ("FIN".equals(message)) {
                                System.out.println("Le jeu est termine.");
                                break;
                            }
                        } else if (retourServeur instanceof Joueur) {
                            Joueur joueurRecu = (Joueur) retourServeur;
                        } else {
                            break; 
                        }
                           
                            // Attendre le retour du serveur avant de continuer
                            
                            if ("FIN".equals(retourServeur)) {
                                System.out.println("Le jeu est termine.");
                                break;
                            }
                        }

                     catch (IOException | ClassNotFoundException e) {
                        e.printStackTrace();
                    }
                    break;

                case 3: // Quitter
                    System.out.println("Merci d'avoir joue !");
                    jeuEnCours = false;
                    break;

                default:
                    System.out.println("Choix invalide !");
            }
        }

        scanner.close();
	}

}