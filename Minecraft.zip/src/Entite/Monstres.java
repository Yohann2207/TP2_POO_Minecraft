package Entite;

import Item.Outils;
import Item.Armure;
import Item.Item;

public class Monstres extends Entite{
	
	private Item ressource;
	
	public Monstres(String nom, Item ressource) {
		super(nom,60,10,20); // PV, PD, PA
		this.ressource = ressource;
	}
	
	public Item getRessource() {
		return ressource;
	}
	
	public void porterArmure(Armure armure) {
		setPointsDeDefense(getPointsDeDefense() + armure.getPointDeDefense());
	}
	
	public void porterArme(Outils outils) {
		setPointsDattaque(getPointsDattaque() + outils.getPointDattaque());
	}

	public void attaquer(Entite cible) {
		System.out.println(getNom() + " attaque " + cible.getNom() + " !");
        cible.subirDegats(getPointsDattaque());
	}
	
	public boolean est_vivant() {
        return getPointsDeVie() != 0; 
    }

}
