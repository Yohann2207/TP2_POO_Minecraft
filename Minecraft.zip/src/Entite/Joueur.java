package Entite;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import Bloc.Bloc;
import Bloc.Bloc_liquide;
import Bloc.Bloc_mangeable;
import Bloc.Bloc_solide;
import Craft.Recette;
import Craft.TableCraft;
import Item.Outils;
import Item.Armure;
import Item.Item;

public class Joueur extends Entite implements Serializable{
	
	private boolean porteArmure = false;
	private boolean porteArme = false;
    private ArrayList<Item> inventaire;
    private Armure armureEquipee = null;
    private Outils armeEquipee = null;


    public Joueur(String nom) {
        super(nom, 100, 30, 30); // PV, PD, PA
        this.inventaire = new ArrayList<>();
    }

    public void ajouterInventaire(Item objet) {
    	if(inventaire.size() < 36) {
    		inventaire.add(objet);
            System.out.println(objet.getNom() + " ajoute a l'inventaire.");
    	}
    	else {
    		System.out.println("Inventaire plein");
    	}
    }
    
    public void supprimerInventaire(Item objet) {
    	if(inventaire.size() == 0) {
            System.out.println("Rien a supprimer");
    	}
    	else {
    		inventaire.remove(objet);
    		System.out.println(objet.getNom() + " a ete supprime de l'inventaire.");
    	}
    }

    public void afficherInventaire() {
        System.out.println("Inventaire de " + getNom() + ":");
        int index = 1;
        for (Object bloc : inventaire) {
            System.out.println(index + ". " + bloc);
            index++;
        }
    }
    
    public void equiperArmure(Armure armure) {
    	if (!porteArmure) { // Vérifie si l'armure n'est pas déjà équipée
            int pointsDeDefenseAvant = this.getPointsDeDefense(); // Stocke les points de défense actuels
            setPointsDeDefense(this.getPointsDeDefense() + armure.getPointDeDefense());
            this.armureEquipee = armure; // Met à jour l'armure équipée
            porteArmure = true; // Maintenant, une armure est équipée
            System.out.println("Vous avez equipe l'armure : " + armure.getNom());
            System.out.println("Points de défense augmentes de " + (this.getPointsDeDefense() - pointsDeDefenseAvant) + " (Total : " + this.getPointsDeDefense() + ")");
        } else {
            System.out.println("Vous portez deja une armure.");
        }
    }
    
    public void enleverArmure(Armure armure) {
    	if (porteArmure && armure == armureEquipee) { // Vérifie si une armure est équipée
            int pointsDeDefenseAvant = this.getPointsDeDefense(); // Stocke les points de défense actuels
            setPointsDeDefense(this.getPointsDeDefense() - armure.getPointDeDefense());
            porteArmure = false; // Déséquipe l'armure
            armureEquipee = null; // Réinitialise l'équipement
            System.out.println("Vous avez retire l'armure : " + armure.getNom());
            System.out.println("Points de defense diminues de " + (pointsDeDefenseAvant - this.getPointsDeDefense()) + " (Total : " + this.getPointsDeDefense() + ")");
        } else {
            System.out.println("Vous ne portez pas d'armure.");
        }
    }
	
	public void equiperArme(Outils outils) {
		if (!porteArme) { // Vérifie si une arme n'est pas déjà équipée
	        int pointsDattaqueAvant = this.getPointsDattaque(); // Stocke les points d'attaque actuels
	        setPointsDattaque(this.getPointsDattaque() + outils.getPointDattaque());
	        this.armeEquipee = outils; // Met à jour l'arme équipée
	        porteArme = true; // Maintenant, une arme est équipée
	        System.out.println("Vous avez equipe l'arme : " + outils.getNom());
	        System.out.println("Points d'attaque augmentes de " + (this.getPointsDattaque() - pointsDattaqueAvant) + " (Total : " + this.getPointsDattaque() + ")");
	    } else {
	        System.out.println("Vous possedez déjà un outil.");
	    }
	}
	
	public void enleverArme(Outils outils) {
		if (porteArme && outils == armeEquipee) { // Vérifie si une arme est équipée
	        int pointsDattaqueAvant = this.getPointsDattaque(); // Stocke les points d'attaque actuels
	        setPointsDattaque(this.getPointsDattaque() - outils.getPointDattaque());
	        porteArme = false; // Déséquipe l'arme
	        armeEquipee = null; // Réinitialise l'équipement
	        System.out.println("Vous avez retire l'arme : " + outils.getNom());
	        System.out.println("Points d'attaque diminues de " + (pointsDattaqueAvant - this.getPointsDattaque()) + " (Total : " + this.getPointsDattaque() + ")");
	    } else {
	        System.out.println("Vous ne portez pas d'arme.");
	    }
	}

    @Override
    public void attaquer(Entite cible) {
        cible.subirDegats(getPointsDattaque());
    }
    
	public ArrayList<Item> getInventaire() {
		return inventaire;
	}
    
    public String proba() {
        double random = Math.random(); // Génère un nombre entre 0.0 et 1.0
        
        if (random < 0.4) { // 40% de chances de ne rien trouver
            return "rien";
        } else if (random < 0.7) { // 30% de chances de rencontrer un monstre
            return "monstre";
        } else { // 30% de chances de trouver un bloc
            return "bloc";
        }
    }
    
    public void crafter() {
        Scanner scanner = new Scanner(System.in);
        boolean encore = true;
        TableCraft table = TableCraft.getTable();
        ArrayList<Item> temp = new ArrayList<>(); //temp stocke les items que le joueur veut utiliser pour crafter
        int recettes_pos = 0; 
        this.afficherInventaire();

        // Ajout d'objets dans temp
        while (encore) {
            System.out.println("Quel objet voulez-vous utiliser (tapez -1 pour ne rien ajouter) : ");
            int choix_uti = scanner.nextInt();
            if (choix_uti > -1 && temp.size() < 9) {
                temp.add(inventaire.get(choix_uti - 1));
            } else {
                encore = false;
            }
        }

        // Affichage des recettes valides
        System.out.println("Vous pouvez crafter les objets suivants : ");
        ArrayList<Recette> recettesPossibles = new ArrayList<>();
        for (int i = 0; i < table.nb_recettes(); i++) {
            Recette recette = table.getRecettes().get(i);
            if (recette.peut_etre_fabriquee(temp)) {
                System.out.println((recettes_pos + 1) + ". " + recette.getResultat().getNom());
                recettesPossibles.add(recette);
                recettes_pos++;
            }
        }

        // Choisir une recette
        System.out.println("Choisissez une recette à fabriquer (ou tapez 0 pour annuler) : ");
        int choixRecette = scanner.nextInt();

        if (choixRecette < 1 || choixRecette > recettes_pos) {
            System.out.println("IMPOSSIBLE ou entrée invalide.");
        } else {
            // La recette choisie est valide
            Recette recetteChoisie = recettesPossibles.get(choixRecette - 1);

            // Supprimer les objets utilisés pour crafter
            for (Item item : temp) {
                supprimerInventaire(item);
            }

            // Ajouter l'objet fabriqué
            Item objetCrafte = recetteChoisie.getResultat();
            ajouterInventaire(objetCrafte);
            System.out.println("Vous avez fabriqué : " + objetCrafte.getNom());
        }
    }
    
    public void se_deplacer() {
        boolean en_cours = true;

        // Liste prédéfinie des monstres possibles.
        ArrayList<Monstres> listeDeMonstres = new ArrayList<>();
        listeDeMonstres.add(new Monstres("Creeper", new Item("Poudre a canon")));
        listeDeMonstres.add(new Monstres("Squelette", new Item("Poudre d'os")));
        listeDeMonstres.add(new Monstres("Sorciere", new Item("Potion")));
        listeDeMonstres.add(new Monstres("Araignee", new Item("Toile")));
        listeDeMonstres.add(new Monstres("Zombie", new Item("Chair putrefiee")));

        // Liste des blocs disponibles dans le monde.
        ArrayList<Bloc> listeDeBlocs = new ArrayList<>();
        listeDeBlocs.add(new Bloc_solide("Bois", true, new Item("Bois")));
        listeDeBlocs.add(new Bloc_solide("Ble", true, new Item("Ble")));
        listeDeBlocs.add(new Bloc_solide("Cuir", true, new Item("Cuir")));
        listeDeBlocs.add(new Bloc_solide("Baton en bois", true, new Item("Baton en bois")));
        listeDeBlocs.add(new Bloc_solide("Pierre", true, new Item("Pierre")));
        listeDeBlocs.add(new Bloc_solide("Fer", true, new Item("Fer")));
        listeDeBlocs.add(new Bloc_solide("Or", true, new Item("Or")));
        listeDeBlocs.add(new Bloc_solide("Diamant", true, new Item("Diamant")));
        listeDeBlocs.add(new Bloc_liquide("Eau", new Item("Eau")));
        listeDeBlocs.add(new Bloc_liquide("Lave", new Item("Lave")));
        listeDeBlocs.add(new Bloc_mangeable("Pomme", 5));
        listeDeBlocs.add(new Bloc_mangeable("Pain", 3));
        listeDeBlocs.add(new Bloc_mangeable("Steak", 10));
        listeDeBlocs.add(new Bloc_mangeable("Carotte", 4));
        listeDeBlocs.add(new Bloc_solide("Charbon", true, new Item("Charbon")));
        listeDeBlocs.add(new Bloc_solide("Quartz", true, new Item("Quartz")));

        Scanner scanner = new Scanner(System.in);

        while (en_cours) {
            // Détermine l'événement actuel en appelant la méthode `proba`.
            String actuel = proba(); 

            // Si le joueur ne trouve rien, affiche un message et sort de la boucle.
            if (actuel.equals("rien")) {
                System.out.println("Vous vous deplacez, mais ne trouvez rien.");
                break;
            }

            // Si le joueur rencontre un monstre
            else if (actuel.equals("monstre")) {
                // Sélectionne un monstre aléatoire dans la liste.
                Monstres le_monstre = listeDeMonstres.get((int) (Math.random() * listeDeMonstres.size()));
                System.out.println("Un " + le_monstre.getNom() + " apparait !");

                // Boucle de combat tant que les deux sont vivants.
                while (le_monstre.estVivant() && this.estVivant()) {
                    this.attaquer(le_monstre); // Le joueur attaque le monstre.

                    // Si le monstre est vaincu, gestion du loot.
                    if (!le_monstre.estVivant()) {
                        System.out.println("Vous avez vaincu : " + le_monstre.getNom() + " !");

                        // Loot laissé par le monstre.
                        Item loot = le_monstre.getRessource();
                        System.out.println("Le " + le_monstre.getNom() + " a laisse tomber : " + loot.getNom());
                        System.out.println("Voulez-vous ramasser cet objet ? (oui/non)");
                        String choix = scanner.nextLine().toLowerCase();

                        // Ajoute le loot à l'inventaire si l'utilisateur choisit "oui".
                        if (choix.equals("oui")) {
                            this.ajouterInventaire(loot);
                        } else {
                            System.out.println("Vous laissez l'objet et continuez votre chemin.");
                        }
                        break; // Fin du combat.
                    }

                    // Le monstre attaque le joueur.
                    le_monstre.attaquer(this);

                    // Si le joueur est vaincu, fin de la partie.
                    if (!this.estVivant()) {
                        System.out.println("Vous avez ete vaincu par : " + le_monstre.getNom() + "...");
                        System.out.println("Fin de la partie.");
                        System.exit(0); // Quitte le programme.
                    }
                }
                break; 
            }

            // Si le joueur trouve un bloc
            else if (actuel.equals("bloc")) {
                // Sélectionne un bloc aléatoire dans la liste.
                Bloc le_bloc = listeDeBlocs.get((int) (Math.random() * listeDeBlocs.size()));
                System.out.println("Vous trouvez un bloc : " + le_bloc.getNom());

                // Demande si le joueur veut ramasser le bloc.
                System.out.println("Voulez-vous ramasser ce bloc ? (oui/non)");
                String choix = scanner.nextLine().toLowerCase();

                if (choix.equals("oui")) {
                    this.ajouterInventaire(le_bloc);
                } 
                else {
                    // Si le joueur ne ramasse pas le bloc.
                    System.out.println("Vous laissez le bloc et continuez votre chemin.");
                }
                break; 
            }
        }
    }


	public Armure getArmureEquipee() {
	    return armureEquipee;
	}

	public Outils getArmeEquipee() {
	    return armeEquipee;
	}

    
}


