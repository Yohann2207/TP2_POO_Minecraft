package Entite;

import java.io.Serializable;

public abstract class Entite implements Serializable{
	
    private String nom;
    private int pointsDeVie;
    private int pointsDeDefense;
    private int pointsDattaque;

    public Entite(String nom, int pointsDeVie, int pointsDeDefense, int pointsDattaque) {
        this.nom = nom;
        this.pointsDeVie = pointsDeVie;
        this.pointsDeDefense = pointsDeDefense;
        this.pointsDattaque = pointsDattaque;
    }

    public int getPointsDeVie() {
		return pointsDeVie;
	}

	public void setPointsDeVie(int pointsDeVie) {
		this.pointsDeVie = pointsDeVie;
	}

	public int getPointsDeDefense() {
		return pointsDeDefense;
	}

	public void setPointsDeDefense(int pointsDeDefense) {
		this.pointsDeDefense = pointsDeDefense;
	}

	public int getPointsDattaque() {
		return pointsDattaque;
	}

	public void setPointsDattaque(int pointsDattaque) {
		this.pointsDattaque = pointsDattaque;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public void subirDegats(int degats) {
        int damage = Math.max(1, degats - pointsDeDefense); //on utilise la méthode max avec 1 pour éviter de retourner des valeurs négatives
        pointsDeVie -= damage;
        System.out.println(nom + " subit " + damage + " points de degats. PV restants: " + pointsDeVie);
    }

    public boolean estVivant() {
        return pointsDeVie > 0;
    }

    public abstract void attaquer(Entite cible);
    
    public String getNom() {
    	return nom;
    }
}

