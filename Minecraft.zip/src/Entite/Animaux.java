package Entite;

import Item.Item;

public class Animaux extends Entite{
	
	private Item ressource;
	
	public Animaux(String nom, Item ressource) {
		super(nom,50,5,0);
		this.ressource = ressource;
	}
	
	public Item getRessource() {
		return ressource;
	}
	
	public void attaquer(Entite cible) {
		cible.subirDegats(0);
	}
}
