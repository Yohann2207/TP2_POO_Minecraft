package Craft;

import java.io.Serializable;
import java.util.ArrayList;

import Bloc.Bloc_mangeable;
import Item.Armure;
import Item.Item;
import Item.Outils;

public class Recette implements Serializable{

    private ArrayList<Item> ingredients; 
    private Item resultat;
	private int PointsDeDefense;
	private int PointsDattaque;
	private int PointsDeVie;

    public Recette(Item resultat) {
        this.ingredients = new ArrayList<>();
        this.resultat=resultat; 
    }
    
    public Recette(Armure resultat, int PointDeDefense) {
        this.ingredients = new ArrayList<>();
        this.resultat=resultat;
        this.PointsDeDefense = PointDeDefense;
    }
    
    public Recette(Outils resultat, int PointDattaque) {
        this.ingredients = new ArrayList<>();
        this.resultat=resultat; 
        this.PointsDattaque = PointDattaque;
    }
    
    public Recette(Bloc_mangeable resultat, int PointDeVie) {
        this.ingredients = new ArrayList<>();
        this.resultat=resultat; 
        this.PointsDeVie = PointDeVie;
    }

    public void ajouterIngredients(Item ingredient) {
        ingredients.add(ingredient);
    }

    public Item getResultat() {
        return resultat; 
    }
    public String toString() {
        String res = "";
        for(int i = 0 ; i < ingredients.size() ; i++) {
            res = res + " " + ingredients.get(i).getNom();
        }
        return res;
    }

    public boolean peut_etre_fabriquee(ArrayList<Item> ingredients) {
        ArrayList<Item> requis = new ArrayList<>(this.ingredients); // Copie des ingrédients requis
        for (Item item : ingredients) {
            requis.remove(item); // Supprime un item correspondant dans la liste des requis
        }
        return requis.isEmpty(); // Vérifie si tous les requis ont été fournis
    }

	public ArrayList<Item> getIngredients() {
		return ingredients;
	}

}