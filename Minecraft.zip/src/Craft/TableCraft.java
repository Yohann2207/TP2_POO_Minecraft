package Craft;

import java.io.Serializable;
import java.util.ArrayList;

public class TableCraft implements Serializable{
	
	private ArrayList<Recette> recettes;
	private static TableCraft table; //C'est un singleton
	
	public TableCraft() {
		this.recettes = new ArrayList<>();
	}
	
	public void ajouterRecette(Recette recette) {
		recettes.add(recette);
	}
	
	public int nb_recettes() {
	     return recettes.size();
	    }

	public static TableCraft getTable() {
	    if (table == null) {
	        table = new TableCraft(); // Initialise la table de crafting si elle est null
	    }
	    return table;
	}

	public ArrayList<Recette> getRecettes() {
	     return recettes;
	    }

}
