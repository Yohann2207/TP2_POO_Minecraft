package Item;

public class Armure extends Item{
	
	private int PointDeDefense;
	
	public Armure(String nom, int PointDeDefense) {
		super(nom);
		this.PointDeDefense = PointDeDefense;
	}

	public int getPointDeDefense() {
		return PointDeDefense;
	}
	
	

}
