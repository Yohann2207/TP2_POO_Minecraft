package Item;

public class Outils extends Item{
	
private int PointDattaque;
	
	public Outils(String nom, int PointDattaque) {
		super(nom);
		this.PointDattaque = PointDattaque;
	}

	public int getPointDattaque() {
		return PointDattaque;
	}

}
