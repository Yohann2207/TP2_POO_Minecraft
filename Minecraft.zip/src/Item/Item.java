package Item;

import java.io.Serializable;

public class Item implements Serializable{
    private String nom;

    public Item(String nom) {
        this.nom = nom;
    }

    public String getNom() {
        return nom;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
        	return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
        	return false;
        }
        Item item = (Item) obj;
        return nom.equals(item.nom); // Comparaison basée sur le nom
    }

    public String toString() {
        return nom;
    }
}
