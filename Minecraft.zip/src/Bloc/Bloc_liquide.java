package Bloc;

import Item.Item;

public class Bloc_liquide extends Bloc  {

    public Bloc_liquide(String nom, Item ressource) {
        super(nom, false, false, false, ressource); 
    }
}
