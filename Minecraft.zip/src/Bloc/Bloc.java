package Bloc;

import Item.Item;

public class Bloc extends Item{

    private boolean est_cassable;
    private boolean est_mangeable; 
    private boolean est_solide; 
    private boolean est_collecte; 
    private Item ressource; 


    public Bloc(String nom, boolean est_cassable, boolean est_mangeable, boolean est_solide, Item ressource) {
        super(nom);
        this.est_cassable=est_cassable; 
        this.est_mangeable=est_mangeable; 
        this.est_solide=est_solide; 
        this.est_collecte=false; 
        this.ressource=ressource; 
    }


	public Item getRessource() {
        return ressource;
    }

    public boolean isEst_collecte() {
        return est_collecte;
    }

    public boolean isEst_cassable() {
        return est_cassable;
    }

    public boolean isEst_mangeable() {
        return est_mangeable;
    }

    public boolean isEst_solide() {
        return est_solide;
    }

    public void setEst_collecte(boolean est_collecte) {
        this.est_collecte = est_collecte;
    }

	public String toString() {
		return getNom();
	}

}