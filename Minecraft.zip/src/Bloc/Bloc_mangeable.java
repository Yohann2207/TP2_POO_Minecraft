package Bloc;

public class Bloc_mangeable extends Bloc {

    private int points_de_vie; 


    public Bloc_mangeable(String nom, int pdv) {
        super(nom, false, true ,false, null); 
        this.points_de_vie=pdv; 
    }

	public int getPointsDeVie() {
		return points_de_vie;
	}
}
