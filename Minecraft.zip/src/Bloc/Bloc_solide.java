package Bloc;

import Item.Item;

public class Bloc_solide extends Bloc {


    public Bloc_solide(String nom, boolean est_cassable, Item ressource) {
        super(nom, est_cassable, false, true, ressource); 
    }

}
