package PVP;


import java.net.ServerSocket;
import java.net.Socket;

import Entite.Joueur;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;


public class Serveur {
	
		public static void main(String[] args) throws ClassNotFoundException {
			// TODO Auto-generated method stub
				
				ServerSocket serveur;
				
				try {
					serveur = new ServerSocket(7003);
					System.out.println("En attente de connexion ... ");
					
					while (true) {
						
					
					
					Socket socket1 = serveur.accept();
					System.out.println("Nouvel utilisateur connecté, en attente d'un autre joueur ... ");
					Socket socket2 = serveur.accept();
					System.out.println("Nouvel utilisateur connecté, le combat va commencer  ... ");
					 
					
					
					 ObjectOutputStream oos1 = new ObjectOutputStream(socket1.getOutputStream());
					 ObjectOutputStream oos2 = new ObjectOutputStream(socket2.getOutputStream());
					
					
					 ObjectInputStream ois1 = new ObjectInputStream(socket1.getInputStream());
					 ObjectInputStream ois2 = new ObjectInputStream(socket2.getInputStream());

					 
					 
					 
			         Joueur j1 = (Joueur) ois1.readObject();
			         Joueur j2 = (Joueur) ois2.readObject();

					while (j1.estVivant() && j2.estVivant()) {
						j1.attaquer(j2);
						oos1.writeObject(j1);
		                oos1.writeObject(j2);
		                oos2.writeObject(j1);
		                oos2.writeObject(j2);
		                if (j2.estVivant()==false) {
		                	System.out.println("Joueur 1 a gagné ! ");
		                	break; 
		                }
		                j2.attaquer(j1);
						oos1.writeObject(j1);
		                oos1.writeObject(j2);
		                oos2.writeObject(j1);
		                oos2.writeObject(j2);
		                if (j1.estVivant()==false) {
		                	System.out.println("Joueur 2 a gagné ! ");
		                	break; 
		                }
					}
					 
				}					
		}
			
				catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
			
		}
}
